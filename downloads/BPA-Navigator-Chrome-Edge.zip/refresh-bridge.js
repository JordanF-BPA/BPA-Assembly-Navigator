(() => {
  'use strict';
  const url = new URL(location.href);
  if (url.origin !== 'https://jordanf-bpa.github.io' ||
      url.pathname !== '/BPA-Assembly-Navigator/helper-refresh.html' || window.parent === window) return;
  const requestId = url.searchParams.get('requestId');
  const projectId = url.searchParams.get('projectId');
  const modelId = url.searchParams.get('modelId');
  if (!/^[a-f0-9-]{36}$/.test(requestId || '') ||
      ![projectId,modelId].every(value => /^[A-Za-z0-9_-]{1,64}$/.test(value || ''))) return;
  function reply(result) {
    window.parent.postMessage({type:'bpa-refresh-result',requestId,ok:result?.ok === true,
      error:result?.error || null}, url.origin);
  }
  chrome.runtime.sendMessage({type:'bpa-refresh-connect',requestId,projectId,modelId})
    .then(reply, error => reply({ok:false,error:error.message}));
})();
