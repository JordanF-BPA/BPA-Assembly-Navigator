(() => {
  'use strict';
  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483646';
  const shadow = host.attachShadow({mode:'closed'});
  shadow.innerHTML = `<style>
    *{box-sizing:border-box}section{position:absolute;left:24px;top:100px;width:300px;max-width:calc(100vw - 16px);max-height:calc(100vh - 16px);overflow:auto;pointer-events:auto;background:white;color:#242424;border:1px solid #2a5fa4;border-radius:10px;padding:16px;box-shadow:0 4px 20px #0004;font:15px 'Segoe UI',sans-serif}
    section[hidden]{display:none}h2{font-size:18px;margin:0;padding:6px 0;cursor:move;touch-action:none;user-select:none}h2:focus-visible{outline:2px solid #2a5fa4}p{margin:10px 0}nav{display:flex;flex-wrap:wrap;gap:8px}button{font:600 14px 'Segoe UI',sans-serif;color:#2a5fa4;border:1px solid #2a5fa4;border-radius:5px;padding:9px 12px;background:white;cursor:pointer}button:disabled{opacity:.5;cursor:default}.hint{font-size:11px;color:#666}
    </style><section hidden role="region" aria-label="Assembly navigation">
    <h2 tabindex="0" title="Drag to move, or use arrow keys">Drawing assemblies</h2>
    <p class="count" role="status" aria-live="polite"></p><nav>
    <button data-direction="-1" aria-label="Previous assembly">← Previous</button>
    <button data-direction="1" aria-label="Next assembly">Next →</button>
    <button data-direction="0">Show all</button></nav><p class="hint">Drag the heading to move</p></section>`;
  document.documentElement.append(host);
  const panel = shadow.querySelector('section');
  const heading = shadow.querySelector('h2');
  const counter = shadow.querySelector('.count');
  const buttons = [...shadow.querySelectorAll('button')];
  let state = null, lastSeen = 0, drag = null, waiting = false;
  const isViewer = () => /^\/projects\/[^/]+\/viewer\/3d$/.test(location.pathname);
  function position(x,y) {
    const box = panel.getBoundingClientRect();
    panel.style.left = Math.max(0,Math.min(x,innerWidth-box.width))+'px';
    panel.style.top = Math.max(0,Math.min(y,innerHeight-box.height))+'px';
  }
  function paint() {
    panel.hidden = !state || state.count < 2 || !isViewer();
    if (panel.hidden) return;
    if (heading.textContent !== state.title) heading.textContent = state.title;
    const text = state.index < 0 ? 'Showing all '+state.count+' assemblies' : 'Assembly '+(state.index+1)+' of '+state.count;
    if (counter.textContent !== text) counter.textContent = text;
    // The Navigator checks its live busy state on each request. A cached
    // heartbeat must not leave these buttons permanently disabled.
    buttons.forEach(button => { button.disabled = waiting; });
    const box = panel.getBoundingClientRect();
    position(box.left,box.top);
  }
  chrome.runtime.onMessage.addListener((message,sender,reply) => {
    if (message?.type !== 'bpa-floating-state') return;
    if (!isViewer()) {panel.hidden=true;reply({ok:false});return;}
    state = message.state;
    lastSeen = Date.now();
    paint();
    reply({ok:true});
  });
  buttons.forEach(button => button.addEventListener('click', async () => {
    if (!state || waiting || panel.hidden) return;
    waiting = true; paint();
    try {
      const result = await chrome.runtime.sendMessage({type:'bpa-floating-action',token:state.token,direction:Number(button.dataset.direction)});
      shadow.querySelector('.hint').textContent = result?.ok ? 'Drag the heading to move' :
        result?.error || 'Navigator unavailable. Refresh Connect and retry.';
    } catch (_) {
      lastSeen = 0;
      shadow.querySelector('.hint').textContent = 'Helper disconnected. Refresh Connect and retry.';
    } finally {waiting=false;paint();}
  }));
  heading.addEventListener('pointerdown',event => {
    if(event.button !== 0 || drag)return;
    const box=panel.getBoundingClientRect();
    drag={id:event.pointerId,x:event.clientX-box.left,y:event.clientY-box.top};
    heading.setPointerCapture(event.pointerId);event.preventDefault();
  });
  heading.addEventListener('pointermove',event => {
    if(drag?.id===event.pointerId)position(event.clientX-drag.x,event.clientY-drag.y);
  });
  for(const name of ['pointerup','pointercancel','lostpointercapture']) heading.addEventListener(name,event => {
    if(drag?.id!==event.pointerId)return;
    drag=null;
    if(heading.hasPointerCapture(event.pointerId))heading.releasePointerCapture(event.pointerId);
  });
  heading.addEventListener('keydown',event => {
    const delta={ArrowLeft:[-10,0],ArrowRight:[10,0],ArrowUp:[0,-10],ArrowDown:[0,10]}[event.key];
    if(!delta)return;
    event.preventDefault();const box=panel.getBoundingClientRect();position(box.left+delta[0],box.top+delta[1]);
  });
  window.addEventListener('resize',paint);
  setInterval(paint,1000);
})();
