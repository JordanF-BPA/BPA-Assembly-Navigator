"use strict";
document.addEventListener('bpa-model-session-request', event => {
  const requestId = event.detail;
  chrome.runtime.sendMessage({type:'bpa-model-session'}).then(result => {
    document.dispatchEvent(new CustomEvent('bpa-model-session-result', {
      detail:JSON.stringify({requestId,session:result?.session || null})
    }));
  }).catch(()=>{});
});
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type !== 'bpa-remembered-model') return;
  let modelId = null;
  try {
    if (/^[A-Za-z0-9_-]{1,64}$/.test(message.projectId || '')) {
      const choice = JSON.parse(localStorage.getItem('BPA_PROJECT_MODEL_V1:' + message.projectId));
      if (message.session && choice?.session === message.session &&
          choice.projectId === message.projectId && /^[A-Za-z0-9_-]{1,64}$/.test(choice.modelId || ''))
        modelId = choice.modelId;
    }
  } catch (_) { /* Missing or unavailable storage keeps normal navigation. */ }
  reply({modelId});
});
document.addEventListener('bpa-stepper-state', event => {
  let state;
  try { state = JSON.parse(event.detail); } catch (_) { return; }
  chrome.runtime.sendMessage({type:'bpa-stepper-state',state}).then(result => {
    if (result?.ok) document.dispatchEvent(new CustomEvent('bpa-stepper-overlay-ready'));
  }).catch(()=>{});
});
chrome.runtime.onMessage.addListener((message,sender,reply) => {
  if (message?.type !== 'bpa-stepper-action') return;
  const requestId = crypto.randomUUID();
  let timer;
  function finish(result) {
    clearTimeout(timer);
    document.removeEventListener('bpa-stepper-action-result',receive);
    reply(result);
  }
  function receive(event) {
    let result;
    try { result=JSON.parse(event.detail); } catch (_) { return; }
    if (result.requestId === requestId) finish(result);
  }
  document.addEventListener('bpa-stepper-action-result',receive);
  timer=setTimeout(()=>finish({ok:false,error:'Navigator did not respond. Refresh Connect and retry.'}),15000);
  document.dispatchEvent(new CustomEvent('bpa-stepper-action',{detail:JSON.stringify({...message,requestId})}));
  return true;
});
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type !== "bpa-fast-drawing") return;
  const job = message.job;
  let timer;
  function finish(result) {
    clearTimeout(timer);
    document.removeEventListener("bpa-fast-drawing-result", receive);
    reply(result);
  }
  function receive(event) {
    let data;
    try { data = JSON.parse(event.detail); } catch (_) { return; }
    if (data.requestId === job.requestId) finish(data);
  }
  document.addEventListener("bpa-fast-drawing-result", receive);
  timer = setTimeout(() => finish({ok:false}), 1200);
  document.dispatchEvent(new CustomEvent("bpa-fast-drawing", {detail:JSON.stringify(job)}));
  return true;
});
// Relay only the narrowly scoped handoff event. The worker validates both tabs.
document.addEventListener("bpa-direct-tab-handoff", event => {
  let detail;
  try { detail = JSON.parse(event.detail); } catch (_) { return; }
  chrome.runtime.sendMessage(detail).catch(error =>
    console.debug("BPA tab helper unavailable:", error.message));
});
