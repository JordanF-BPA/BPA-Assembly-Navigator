"use strict";
const ROOT = "https://jordanf-bpa.github.io/BPA-Assembly-Navigator/";
const CONNECT = "https://web.connect.trimble.com";
const PREFIX = "bpa-handoff-";
const TTL = 15000;
const MODEL_SESSION = 'bpa-model-choice-session';
const LOGIN_PENDING = 'bpa-login-drawing-';
const LOGIN_TTL = 30 * 60 * 1000;

// Session storage survives service-worker suspension, but not browser restart.
// Keep requests per tab so simultaneous sign-ins cannot exchange drawings.
async function rememberLoginDrawing(tabId, url) {
  if (!parseDirect(url)) return;
  const key = LOGIN_PENDING + tabId;
  const previous = (await chrome.storage.session.get(key))[key];
  if (previous?.url === url && Date.now() - previous.time < LOGIN_TTL) return;
  await chrome.storage.session.set({[key]: {url, time: Date.now(), replayed: false}});
}
async function resumeLoginDrawing(tabId) {
  const key = LOGIN_PENDING + tabId;
  const pending = (await chrome.storage.session.get(key))[key];
  if (!pending) return;
  if (Date.now() - pending.time >= LOGIN_TTL || !parseDirect(pending.url)) {
    await chrome.storage.session.remove(key);
    return;
  }
  if (pending.replayed) return;
  const tab = await chrome.tabs.get(tabId);
  if (tab.pendingUrl || tab.status !== 'complete') return;
  let current;
  try { current = new URL(tab.url); } catch (_) { return; }
  const job = parseDirect(pending.url);
  // Never interrupt identity-provider pages, callbacks, another project, or
  // an already-open viewer. Only recover on Connect's generic landing routes.
  if (current.origin !== CONNECT || current.search || current.hash ||
      !['/', '/projects', '/projects/', '/projects/' + job.projectId,
        '/projects/' + job.projectId + '/'].includes(current.pathname)) return;
  // Consume before navigating: a failed login must not cause repeated redirects.
  await chrome.storage.session.set({[key]: {...pending, replayed: true}});
  await chrome.tabs.update(tabId, {url: pending.url});
}
function isConnectTab(tab) {
  try { return new URL(tab.pendingUrl || tab.url).origin === CONNECT; } catch (_) { return false; }
}
async function modelSession(sender) {
  if (sender.tab?.id == null || sender.frameId <= 0 ||
      ![ROOT,ROOT+'index.html'].includes(sender.url?.split('?')[0])) return {session:null};
  if (!isConnectTab(await chrome.tabs.get(sender.tab.id))) return {session:null};
  await chrome.storage.session.remove(LOGIN_PENDING + sender.tab.id);
  const stored = await chrome.storage.session.get(MODEL_SESSION);
  const session = stored[MODEL_SESSION] || crypto.randomUUID();
  await chrome.storage.session.set({[MODEL_SESSION]:session});
  return {session};
}
async function clearClosedModelSession() {
  if (!(await chrome.tabs.query({url:CONNECT+'/*'})).some(isConnectTab))
    await chrome.storage.session.remove([MODEL_SESSION]);
}

function valid(message, sender) {
  return sender.tab?.id != null && sender.frameId > 0 &&
    [ROOT, ROOT + "index.html"].includes(sender.url?.split("?")[0]) &&
    ["received", "sent"].includes(message?.role) &&
    /^[a-f0-9-]{36}$/.test(message.requestId || "") &&
    /^[a-f0-9-]{36}$/.test(message.viewerId || "") &&
    /^[A-Za-z0-9_-]{1,64}$/.test(message.projectId || "") &&
    /^[A-Za-z0-9_-]{1,64}$/.test(message.modelId || "") &&
    /^pos-((?:[a-f0-9]{2}){1,316})-([1-9]\d{0,8})$/.test(message.guid || "");
}
function matches(url, message, role) {
  try {
    const u = new URL(url);
    if (u.origin !== CONNECT) return false;
    const base = "/projects/" + message.projectId;
    if (role === "received") return u.pathname === base + "/viewer/3d" &&
      u.searchParams.getAll("modelId").length === 1 && u.searchParams.get("modelId") === message.modelId;
    const [, hex, qty] = /^pos-([a-f0-9]+)-(\d+)$/.exec(message.guid);
    const drawingPath = base + "/extension/583cfc91-ce7a-84d0-e830-885658dad4fb/" +
      "BPA_NAVIGATOR_DRAWING_" + hex + "_" + qty;
    // Project-only links resolve the remembered model in Navigator. The paired
    // acknowledgement still validates that exact model in the receiving viewer.
    return u.pathname === drawingPath || u.pathname === drawingPath + "_" + message.modelId;
  } catch (_) { return false; }
}
async function handle(message, sender) {
  if (!valid(message, sender)) return;
  const tab = await chrome.tabs.get(sender.tab.id);
  if (tab.pendingUrl || !matches(tab.url, message, message.role)) return;
  const all = await chrome.storage.session.get(null);
  const stale = Object.keys(all).filter(k => k.startsWith(PREFIX) && Date.now() - all[k].time > TTL);
  if (stale.length) await chrome.storage.session.remove(stale);
  const key = PREFIX + message.requestId;
  let record = all[key];
  const signature = [message.viewerId, message.projectId, message.modelId, message.guid].join("|");
  if (!record || Date.now() - record.time > TTL) record = {time: Date.now(), signature};
  if (record.signature !== signature || record.complete) return;
  if (record[message.role] && record[message.role].id !== tab.id) return;
  record[message.role] = {id: tab.id, url: tab.url};
  await chrome.storage.session.set({[key]: record});
  if (!record.received || !record.sent || record.received.id === record.sent.id) return;
  const viewer = await chrome.tabs.get(record.received.id);
  const temporary = await chrome.tabs.get(record.sent.id);
  if (viewer.pendingUrl || temporary.pendingUrl || viewer.url !== record.received.url ||
      temporary.url !== record.sent.url || !matches(viewer.url, message, "received") ||
      !matches(temporary.url, message, "sent")) return;
  await chrome.tabs.update(viewer.id, {active: true});
  await chrome.windows.update(viewer.windowId, {focused: true});
  // Check again after focusing: do not close a tab the user has navigated elsewhere.
  const latest = await chrome.tabs.get(temporary.id);
  if (latest.pendingUrl || latest.url !== temporary.url) return;
  await chrome.tabs.remove(temporary.id);
  record.complete = true;
  await chrome.storage.session.set({[key]: record});
}
let queue = Promise.resolve();
async function refreshConnectTab(message, sender) {
  const denied = {ok:false,error:'The refresh request does not match this Connect viewer.'};
  if (sender.tab?.id == null || sender.frameId <= 0 ||
      !/^[a-f0-9-]{36}$/.test(message.requestId || '') ||
      ![message.projectId,message.modelId].every(value => /^[A-Za-z0-9_-]{1,64}$/.test(value || ''))) return denied;
  let source;
  try { source = new URL(sender.url); } catch (_) { return denied; }
  if (source.origin + source.pathname !== ROOT + 'helper-refresh.html' ||
      ['requestId','projectId','modelId'].some(key => source.searchParams.getAll(key).length !== 1 ||
        source.searchParams.get(key) !== message[key])) return denied;
  const tab = await chrome.tabs.get(sender.tab.id);
  if (tab.pendingUrl || !matches(tab.url,message,'received')) return denied;
  // Bound to the requesting frame's own tab, not the active tab or a supplied ID.
  await chrome.tabs.reload(sender.tab.id);
  return {ok:true};
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type === 'bpa-refresh-connect') {
    queue = queue.then(() => refreshConnectTab(message,sender))
      .then(reply,error => reply({ok:false,error:error.message}));
    return true;
  }
  if (message?.type === 'bpa-model-session') {
    queue = queue.then(() => modelSession(sender)).then(reply, () => reply({session:null}));
    return true;
  }
  if (['bpa-stepper-state','bpa-floating-action'].includes(message?.type)) {
    routeStepper(message,sender).then(result=>reply(result || {ok:false,error:'Navigator did not accept this update.'}),error=>reply({ok:false,error:'Navigator connection: '+error.message}));
    return true;
  }
  if (!valid(message, sender)) return;
  queue = queue.then(() => handle(message, sender)).then(
    () => reply({ok: true}), error => reply({ok: false, error: error.message}));
  return true;
});

function parseDirect(url) {
  try {
    const u = new URL(url);
    if (u.origin !== CONNECT) return null;
    const m = /^\/projects\/([A-Za-z0-9_-]{1,64})\/extension\/583cfc91-ce7a-84d0-e830-885658dad4fb\/BPA_NAVIGATOR_DRAWING_((?:[a-f0-9]{2}){1,316})_([1-9]\d{0,8})(?:_([A-Za-z0-9_-]{1,64}))?$/.exec(u.pathname);
    return m ? {projectId:m[1], modelId:m[4], guid:'pos-'+m[2]+'-'+m[3], requestId:crypto.randomUUID()} : null;
  } catch (_) { return null; }
}
async function fastOpen(tabId, url) {
  const job = parseDirect(url);
  if (!job) return;
  const source = await chrome.tabs.get(tabId);
  if ((source.pendingUrl || source.url) !== url) return;
  const candidates = (await chrome.tabs.query({url:CONNECT+'/*'}))
    .filter(t => t.id !== tabId && !t.pendingUrl && (job.modelId ? matches(t.url, job, 'received') :
      isViewerUrl(t.url) && new URL(t.url).pathname === '/projects/'+job.projectId+'/viewer/3d'))
    .sort((a,b) => Number(b.windowId === source.windowId)-Number(a.windowId === source.windowId));
  for (const candidate of candidates) {
    const delivery = {...job};
    if (!delivery.modelId) {
      // Read the current choice from the existing Navigator frame, avoiding a
      // second cache that could disagree with "Change remembered model".
      try {
        const session = (await chrome.storage.session.get(MODEL_SESSION))[MODEL_SESSION];
        if (!session) continue;
        const choice = await chrome.tabs.sendMessage(candidate.id,
          {type:'bpa-remembered-model',projectId:job.projectId,session});
        if (!/^[A-Za-z0-9_-]{1,64}$/.test(choice?.modelId || '')) continue;
        delivery.modelId = choice.modelId;
        if (!matches(candidate.url,delivery,'received')) continue;
      } catch (_) { continue; }
    }
    let ack;
    try { ack = await chrome.tabs.sendMessage(candidate.id, {type:'bpa-fast-drawing',job:delivery}); }
    catch (_) { continue; }
    if (!ack?.ok || ack.requestId !== job.requestId) continue;
    const viewer = await chrome.tabs.get(candidate.id);
    const current = await chrome.tabs.get(tabId);
    if (viewer.pendingUrl || !matches(viewer.url,delivery,'received') || (current.pendingUrl || current.url) !== url) return;
    await chrome.tabs.update(viewer.id,{active:true});
    await chrome.windows.update(viewer.windowId,{focused:true});
    const latest = await chrome.tabs.get(tabId);
    if ((latest.pendingUrl || latest.url) === url) await chrome.tabs.remove(tabId);
    return;
  }
  // No loaded viewer accepted: leave the original direct link to load normally.
}
const fastAttempts = new Map();
function scheduleFast(tab) {
  const url = tab.pendingUrl || tab.url;
  if (parseDirect(url)) queue = queue.then(() => rememberLoginDrawing(tab.id,url)).catch(()=>{});
  if (!parseDirect(url) || fastAttempts.get(tab.id) === url) return;
  fastAttempts.set(tab.id,url);
  queue = queue.then(() => fastOpen(tab.id,url)).catch(error =>
    console.debug('BPA fast handoff left normal navigation available:',error.message));
}
chrome.tabs.onCreated.addListener(scheduleFast);
chrome.tabs.onUpdated.addListener((id, change, tab) => {
  if (change.url && !isConnectTab(tab)) queue = queue.then(clearClosedModelSession).catch(()=>{});
  if (change.url || change.status === 'loading') scheduleFast(tab);
  if (change.status === 'complete' || change.url) {
    queue = queue.then(() => resumeLoginDrawing(id)).catch(error =>
      console.debug('BPA sign-in recovery unavailable:',error.message));
  }
});
chrome.tabs.onRemoved.addListener(id => {
  fastAttempts.delete(id);
  queue = queue.then(() => chrome.storage.session.remove(LOGIN_PENDING + id)).catch(()=>{});
});
chrome.tabs.onRemoved.addListener(() => {
  queue = queue.then(clearClosedModelSession).catch(()=>{});
});

// Route floating controls only between the top page and its own Navigator frame.
const stepperFrames = new Map();
function isViewerUrl(url) {
  try { const u = new URL(url); return u.origin === CONNECT && /^\/projects\/[^/]+\/viewer\/3d$/.test(u.pathname); }
  catch (_) { return false; }
}
function sameStepperViewer(a,b) {
  try {
    const left=new URL(a),right=new URL(b);
    return isViewerUrl(a) && isViewerUrl(b) && left.pathname===right.pathname &&
      left.searchParams.get('modelId')===right.searchParams.get('modelId');
  } catch (_) { return false; }
}
async function routeStepper(message, sender) {
  if (sender.tab?.id == null) return;
  const tab = await chrome.tabs.get(sender.tab.id);
  if (tab.pendingUrl || !isViewerUrl(tab.url)) return {ok:false,error:'Connect is changing pages. Wait for the viewer and retry.'};
  const ownerKey = 'bpa-stepper-owner-' + tab.id;
  if (!stepperFrames.has(tab.id)) {
    const stored = await chrome.storage.session.get(ownerKey);
    if (stored[ownerKey]) stepperFrames.set(tab.id,stored[ownerKey]);
  }
  if (message.type === 'bpa-stepper-state') {
    if (sender.frameId <= 0 || ![ROOT, ROOT+'index.html'].includes(sender.url?.split('?')[0])) return;
    const s = message.state;
    if (!s || typeof s.token !== 'string' || s.token.length > 100 ||
        typeof s.title !== 'string' || s.title.length > 700 ||
        !Number.isInteger(s.count) || s.count < 0 || s.count > 1000000 ||
        !Number.isInteger(s.index) || s.index < -1 || s.index >= Math.max(1,s.count)) return;
    const owner = stepperFrames.get(tab.id);
    // Idle frames must not clear another Navigator's live controls. A new
    // navigation can explicitly claim ownership; heartbeat messages cannot.
    if (owner && sameStepperViewer(owner.url,tab.url) && owner.frameId !== sender.frameId &&
        !(s.claim === true && s.count > 1)) return;
    if (!owner && s.count < 2) return;
    stepperFrames.set(tab.id, {frameId:sender.frameId, token:s.token, url:tab.url, time:Date.now()});
    await chrome.storage.session.set({[ownerKey]:stepperFrames.get(tab.id)});
    return await chrome.tabs.sendMessage(tab.id, {type:'bpa-floating-state', state:s}, {frameId:0});
  }
  // Validate the current tab above, not the route on which this content
  // script was first loaded. Connect can enter its viewer through SPA routing.
  if (sender.frameId !== 0 || new URL(sender.url).origin !== CONNECT || ![-1,0,1].includes(message.direction))
    return {ok:false,error:'The controls are not in the Connect page frame.'};
  const target = stepperFrames.get(tab.id);
  if (!target) return {ok:false,error:'No Navigator frame is registered. Refresh Connect.'};
  if (!sameStepperViewer(target.url,tab.url)) return {ok:false,error:'The viewer project or model changed. Open the drawing link again.'};
  if (target.token !== message.token) return {ok:false,error:'The drawing changed. Wait for its updated controls.'};
  return await chrome.tabs.sendMessage(tab.id, {type:'bpa-stepper-action', token:target.token, direction:message.direction}, {frameId:target.frameId});
}
chrome.tabs.onRemoved.addListener(id => {
  stepperFrames.delete(id);
  chrome.storage.session.remove('bpa-stepper-owner-'+id).catch(()=>{});
});
